<?php
session_start();
include 'db.php';
if(!isset($_SESSION['user_id']) || $_SESSION['role'] != 'passenger'){
    header("Location: login.php"); exit;
}
$message = "";

if(isset($_POST['request_ride'])){
    $passenger_id = $_SESSION['user_id'];
    $from = $_POST['from_location'];
    $to = $_POST['to_location'];
    $date = $_POST['date_time'];
    $seats = $_POST['seats_requested'];

    $stmt = $conn->prepare("INSERT INTO ride_requests (passenger_id,from_location,to_location,date_time,seats_requested) VALUES (?,?,?,?,?)");
    if($stmt->execute([$passenger_id,$from,$to,$date,$seats])){
        $message = "Ride requested successfully!";
    } else {
        $message = "Error requesting ride.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Request a Ride</title>
<style>
body{font-family:'Segoe UI'; background:#f0f2f5; display:flex; justify-content:center; align-items:center; min-height:100vh;}
.container{background:#fff; padding:40px; border-radius:12px; box-shadow:0 6px 20px rgba(0,0,0,0.1); width:400px;}
h2{text-align:center; margin-bottom:20px;}
input,button{width:100%; padding:12px; margin:8px 0; border-radius:8px; border:1px solid #ccc;}
input:focus{border-color:#2563eb; box-shadow:0 0 5px #2563eb33;}
button{border:none; background:#2563eb; color:#fff; cursor:pointer;}
button:hover{background:#1d4ed8;}
.message{text-align:center; color:green; margin-bottom:15px;}
.nav{text-align:center; margin-bottom:20px;}
.nav a{margin:0 10px; color:#2563eb; text-decoration:none;}
.nav a:hover{text-decoration:underline;}
</style>
</head>
<body>
<div class="container">
<h2>Request a Ride</h2>
<div class="nav">
<a href="index.php">Home</a>
<a href="history.php">My Rides</a>
<a href="logout.php">Logout</a>
</div>
<?php if($message) echo "<div class='message'>$message</div>"; ?>
<form method="POST">
<input type="text" name="from_location" placeholder="From Location" required>
<input type="text" name="to_location" placeholder="To Location" required>
<input type="datetime-local" name="date_time" required>
<input type="number" name="seats_requested" placeholder="Seats" min="1" required>
<button name="request_ride">Request Ride</button>
</form>
</div>
</body>
</html>
