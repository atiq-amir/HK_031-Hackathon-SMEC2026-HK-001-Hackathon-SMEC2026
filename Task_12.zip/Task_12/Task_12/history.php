<?php
session_start();
include 'db.php';

/* Access control */
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$role = $_SESSION['role'];

/* Passenger history */
if ($role === 'passenger') {
    $stmt = $conn->prepare("
        SELECT rr.*, u.name AS driver_name
        FROM ride_requests rr
        LEFT JOIN users u ON rr.driver_id = u.id
        WHERE rr.passenger_id = ?
        ORDER BY rr.date_time DESC
    ");
    $stmt->execute([$user_id]);
    $rides = $stmt->fetchAll(PDO::FETCH_ASSOC);
}

/* Driver history */
if ($role === 'driver') {
    $stmt = $conn->prepare("
        SELECT rr.*, u.name AS passenger_name
        FROM ride_requests rr
        JOIN users u ON rr.passenger_id = u.id
        WHERE rr.driver_id = ?
        ORDER BY rr.date_time DESC
    ");
    $stmt->execute([$user_id]);
    $rides = $stmt->fetchAll(PDO::FETCH_ASSOC);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Ride History</title>

<style>
body {
    font-family: 'Segoe UI', sans-serif;
    background: #f4f6f8;
    padding: 20px;
}

.container {
    max-width: 1000px;
    margin: auto;
    background: #ffffff;
    padding: 30px;
    border-radius: 12px;
    box-shadow: 0 6px 20px rgba(0,0,0,0.1);
}

h2 {
    text-align: center;
    margin-bottom: 20px;
    color: #111827;
}

.nav {
    text-align: center;
    margin-bottom: 20px;
}

.nav a {
    margin: 0 10px;
    color: #2563eb;
    text-decoration: none;
}

.nav a:hover {
    text-decoration: underline;
}

table {
    width: 100%;
    border-collapse: collapse;
}

th, td {
    padding: 12px;
    border-bottom: 1px solid #ddd;
    text-align: center;
}

th {
    background: #f3f4f6;
}

.status {
    padding: 4px 10px;
    border-radius: 8px;
    font-size: 14px;
}

.pending {
    background: #fef3c7;
    color: #92400e;
}

.accepted {
    background: #dcfce7;
    color: #166534;
}

.completed {
    background: #e5e7eb;
    color: #374151;
}
</style>
</head>

<body>
<div class="container">

<h2>My Ride History</h2>

<div class="nav">
    <a href="index.php">Home</a>
    <?php if ($role === 'driver'): ?>
        <a href="driver_requests.php">Requests</a>
    <?php endif; ?>
    <a href="logout.php">Logout</a>
</div>

<table>
<tr>
    <?php if ($role === 'passenger'): ?>
        <th>Driver</th>
    <?php else: ?>
        <th>Passenger</th>
    <?php endif; ?>
    <th>From</th>
    <th>To</th>
    <th>Date & Time</th>
    <th>Seats</th>
    <th>Status</th>
    <th>Map</th>
</tr>

<?php if ($rides): ?>
    <?php foreach ($rides as $ride): ?>
    <tr>
        <td>
            <?= htmlspecialchars(
                $role === 'passenger'
                ? ($ride['driver_name'] ?? 'Not assigned')
                : $ride['passenger_name']
            ) ?>
        </td>
        <td><?= htmlspecialchars($ride['from_location']) ?></td>
        <td><?= htmlspecialchars($ride['to_location']) ?></td>
        <td><?= date("d M Y, H:i", strtotime($ride['date_time'])) ?></td>
        <td><?= $ride['seats_requested'] ?></td>
        <td>
            <span id="status-<?= $ride['id'] ?>" class="status <?= $ride['status'] ?>">
                <?= ucfirst($ride['status']) ?>
            </span>
        </td>
        <td>
            <a href="view_map.php?from=<?= urlencode($ride['from_location']) ?>&to=<?= urlencode($ride['to_location']) ?>" target="_blank">
                View Map
            </a>
        </td>
    </tr>
    <?php endforeach; ?>
<?php else: ?>
<tr>
    <td colspan="6">No ride history found.</td>
</tr>
<?php endif; ?>

</table>

</div>

<script>
function refreshRideStatus() {
    fetch('ride_status_api.php')
        .then(response => response.json())
        .then(data => {
            data.forEach(ride => {
                const statusEl = document.getElementById('status-' + ride.id);
                if (statusEl) {
                    statusEl.innerText = ride.status.charAt(0).toUpperCase() + ride.status.slice(1);
                    statusEl.className = 'status ' + ride.status;
                }
            });
        });
}

setInterval(refreshRideStatus, 5000); // every 5 seconds
</script>


</body>
</html>
