<?php
session_start();
include 'db.php';

// Redirect if not logged in
if(!isset($_SESSION['user_id'])){
    header("Location: login.php");
    exit;
}

$search_from = $_GET['from'] ?? '';
$search_to = $_GET['to'] ?? '';
$message = "";

// Handle booking
if(isset($_GET['book'])){
    $ride_id = $_GET['book'];
    $passenger_id = $_SESSION['user_id'];

    // Check seat availability
    $stmt = $conn->prepare("SELECT seats_available FROM rides WHERE id=?");
    $stmt->execute([$ride_id]);
    $ride = $stmt->fetch(PDO::FETCH_ASSOC);

    if($ride && $ride['seats_available'] > 0){
        // Insert booking
        $stmt = $conn->prepare("INSERT INTO bookings (ride_id, passenger_id) VALUES (?, ?)");
        $stmt->execute([$ride_id, $passenger_id]);

        // Decrement seats
        $stmt = $conn->prepare("UPDATE rides SET seats_available = seats_available - 1 WHERE id=?");
        $stmt->execute([$ride_id]);

        $message = "Seat booked successfully!";
    } else {
        $message = "No seats available for this ride.";
    }
}

// Fetch rides
$sql = "SELECT rides.*, users.name as driver_name 
        FROM rides 
        JOIN users ON rides.driver_id = users.id
        WHERE from_location LIKE ? AND to_location LIKE ? 
        AND date_time >= NOW()
        ORDER BY date_time ASC";

$stmt = $conn->prepare($sql);
$stmt->execute(["%$search_from%", "%$search_to%"]);
$rides = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Available Rides - University RideShare</title>
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background: #f0f2f5;
            padding: 20px;
        }
        .container {
            max-width: 900px;
            margin: auto;
            background: #fff;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 6px 20px rgba(0,0,0,0.1);
        }
        h2 {
            text-align: center;
            margin-bottom: 20px;
            color: #111827;
        }
        .nav a {
            margin: 0 10px;
            color: #2563eb;
            text-decoration: none;
        }
        .nav a:hover {
            text-decoration: underline;
        }
        form.search {
            display: flex;
            justify-content: center;
            margin-bottom: 20px;
        }
        form.search input[type=text] {
            padding: 8px 12px;
            margin: 0 5px;
            border-radius: 8px;
            border: 1px solid #ccc;
        }
        form.search button {
            padding: 8px 15px;
            border: none;
            border-radius: 8px;
            background-color: #2563eb;
            color: #fff;
            cursor: pointer;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }
        table th, table td {
            padding: 12px;
            border-bottom: 1px solid #ddd;
            text-align: center;
        }
        table th {
            background-color: #f3f4f6;
        }
        button.book {
            padding: 6px 12px;
            border: none;
            border-radius: 8px;
            background-color: #16a34a;
            color: #fff;
            cursor: pointer;
        }
        button.book:disabled {
            background-color: #a1a1aa;
            cursor: not-allowed;
        }
        .message {
            text-align: center;
            color: green;
            margin-bottom: 15px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Available Rides</h2>
        <div class="nav">
            <a href="index.php">Home</a>
            <a href="post_ride.php">Post Ride</a>
            <a href="history.php">My Rides</a>
            <a href="logout.php">Logout</a>
        </div>

        <?php if($message) echo "<div class='message'>$message</div>"; ?>

        <!-- Search Form -->
        <form class="search" method="GET">
            <input type="text" name="from" placeholder="From" value="<?= htmlspecialchars($search_from) ?>">
            <input type="text" name="to" placeholder="To" value="<?= htmlspecialchars($search_to) ?>">
            <button type="submit">Search</button>
        </form>

        <table>
            <tr>
                <th>Driver</th>
                <th>From</th>
                <th>To</th>
                <th>Date & Time</th>
                <th>Seats Available</th>
                <th>Action</th>
            </tr>
            <?php if($rides): ?>
                <?php foreach($rides as $ride): ?>
                    <tr>
                        <td><?= htmlspecialchars($ride['driver_name']) ?></td>
                        <td><?= htmlspecialchars($ride['from_location']) ?></td>
                        <td><?= htmlspecialchars($ride['to_location']) ?></td>
                        <td><?= date("d M Y, H:i", strtotime($ride['date_time'])) ?></td>
                        <td><?= $ride['seats_available'] ?></td>
                        <td>
                            <?php if($ride['seats_available'] > 0): ?>
                                <a href="?book=<?= $ride['id'] ?>"><button class="book">Book Seat</button></a>
                            <?php else: ?>
                                <button class="book" disabled>Full</button>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr><td colspan="6">No rides found.</td></tr>
            <?php endif; ?>
        </table>
    </div>
</body>
</html>
