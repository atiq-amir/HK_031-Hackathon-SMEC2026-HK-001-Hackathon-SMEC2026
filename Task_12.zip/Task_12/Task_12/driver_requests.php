<?php
session_start();
include 'db.php';

/* Access control: only logged-in drivers */
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'driver') {
    header("Location: login.php");
    exit;
}

$driver_id = $_SESSION['user_id'];
$message = "";

/* Accept Ride Logic */
if (isset($_GET['accept'])) {
    $ride_id = $_GET['accept'];

    $stmt = $conn->prepare("
        UPDATE ride_requests 
        SET driver_id = ?, status = 'accepted'
        WHERE id = ? AND status = 'pending'
    ");
    if ($stmt->execute([$driver_id, $ride_id])) {
        $message = "Ride accepted successfully!";
    } else {
        $message = "Ride already taken or unavailable.";
    }
}

/* Fetch pending ride requests */
$stmt = $conn->prepare("
    SELECT 
        rr.*, 
        u.name AS passenger_name 
    FROM ride_requests rr
    JOIN users u ON rr.passenger_id = u.id
    WHERE rr.status = 'pending'
    ORDER BY rr.date_time ASC
");
$stmt->execute();
$rides = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Pending Ride Requests</title>

<style>
body {
    font-family: 'Segoe UI', sans-serif;
    background: #f0f2f5;
    padding: 20px;
}

.container {
    max-width: 1000px;
    margin: auto;
    background: #ffffff;
    padding: 30px;
    border-radius: 12px;
    box-shadow: 0 6px 20px rgba(0,0,0,0.1);
}

h2 {
    text-align: center;
    margin-bottom: 20px;
    color: #111827;
}

.nav {
    text-align: center;
    margin-bottom: 20px;
}

.nav a {
    margin: 0 10px;
    color: #2563eb;
    text-decoration: none;
}

.nav a:hover {
    text-decoration: underline;
}

table {
    width: 100%;
    border-collapse: collapse;
}

th, td {
    padding: 12px;
    border-bottom: 1px solid #ddd;
    text-align: center;
}

th {
    background: #f3f4f6;
}

button.accept {
    padding: 6px 14px;
    border: none;
    border-radius: 8px;
    background: #16a34a;
    color: #fff;
    cursor: pointer;
}

button.accept:hover {
    background: #15803d;
}

.message {
    text-align: center;
    color: green;
    margin-bottom: 15px;
}
</style>
</head>

<body>
<div class="container">

<h2>Pending Ride Requests</h2>

<div class="nav">
    <a href="index.php">Home</a>
    <a href="history.php">My Rides</a>
    <a href="logout.php">Logout</a>
</div>

<?php if ($message): ?>
<div class="message"><?= htmlspecialchars($message) ?></div>
<?php endif; ?>

<table>
<tr>
    <th>Passenger</th>
    <th>From</th>
    <th>To</th>
    <th>Date & Time</th>
    <th>Seats</th>
    <th>Action</th>
</tr>

<?php if ($rides): ?>
    <?php foreach ($rides as $ride): ?>
    <tr>
        <td><?= htmlspecialchars($ride['passenger_name']) ?></td>
        <td><?= htmlspecialchars($ride['from_location']) ?></td>
        <td><?= htmlspecialchars($ride['to_location']) ?></td>
        <td><?= date("d M Y, H:i", strtotime($ride['date_time'])) ?></td>
        <td><?= $ride['seats_requested'] ?></td>
        <td>
            <a href="?accept=<?= $ride['id'] ?>">
                <button class="accept">Accept</button>
            </a>
        </td>
    </tr>
    <?php endforeach; ?>
<?php else: ?>
<tr>
    <td colspan="6">No pending ride requests.</td>
</tr>
<?php endif; ?>

</table>
</div>
</body>
</html>
