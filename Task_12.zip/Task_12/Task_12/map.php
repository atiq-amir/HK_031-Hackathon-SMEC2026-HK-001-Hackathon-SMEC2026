<?php
if (!isset($_GET['from']) || !isset($_GET['to'])) {
    exit("Invalid route");
}

$from = urlencode($_GET['from']);
$to   = urlencode($_GET['to']);
?>
<iframe
    width="100%"
    height="350"
    style="border:0;border-radius:12px"
    loading="lazy"
    allowfullscreen
    src="https://www.google.com/maps?q=<?= $from ?>&destination=<?= $to ?>&output=embed">
</iframe>
