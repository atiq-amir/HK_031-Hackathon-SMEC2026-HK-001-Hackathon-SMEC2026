<?php
include 'db.php';
$message = "";

if(isset($_POST['register'])){
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT);
    $role = $_POST['role']; // passenger or driver

    $stmt = $conn->prepare("INSERT INTO users (name,email,password,role) VALUES (?,?,?,?)");
    if($stmt->execute([$name,$email,$password,$role])){
        $message = "Registration successful. <a href='login.php'>Login here</a>";
    } else {
        $message = "Error occurred. Try again!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Register - RideShare</title>
<style>
body{font-family:'Segoe UI'; background:#f0f2f5; display:flex; justify-content:center; align-items:center; height:100vh;}
.container{background:#fff; padding:40px; border-radius:12px; box-shadow:0 6px 20px rgba(0,0,0,0.1); width:400px;}
h2{text-align:center; margin-bottom:20px; color:#111827;}
input,select,button{width:100%; padding:12px; margin:8px 0; border-radius:8px; border:1px solid #ccc;}
input:focus,select:focus{border-color:#2563eb; box-shadow:0 0 5px #2563eb33;}
button{border:none; background:#2563eb; color:#fff; cursor:pointer;}
button:hover{background:#1d4ed8;}
.message{text-align:center; color:green; margin-bottom:15px;}
.login-link{text-align:center; margin-top:10px;}
.login-link a{color:#2563eb; text-decoration:none;}
.login-link a:hover{text-decoration:underline;}
</style>
</head>
<body>
<div class="container">
<h2>Register</h2>
<?php if($message) echo "<div class='message'>$message</div>"; ?>
<form method="POST">
<input type="text" name="name" placeholder="Full Name" required>
<input type="email" name="email" placeholder="Email Address" required>
<input type="password" name="password" placeholder="Password" required>
<select name="role" required>
<option value="passenger">Passenger</option>
<option value="driver">Driver</option>
</select>
<button name="register">Register</button>
</form>
<div class="login-link">
Already have an account? <a href="login.php">Login</a>
</div>
</div>
</body>
</html>
