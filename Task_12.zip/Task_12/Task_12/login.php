<?php
session_start();
include 'db.php';
$message = "";

if(isset($_POST['login'])){
    $email = $_POST['email'];
    $password = $_POST['password'];

    $stmt = $conn->prepare("SELECT * FROM users WHERE email=?");
    $stmt->execute([$email]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if($user && password_verify($password, $user['password'])){
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['name'] = $user['name'];
        $_SESSION['role'] = $user['role'];
        header("Location: index.php");
        exit;
    } else {
        $message = "Invalid email or password!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Login - RideShare</title>
<style>
body{font-family:'Segoe UI'; background:#f0f2f5; display:flex; justify-content:center; align-items:center; height:100vh;}
.container{background:#fff; padding:40px; border-radius:12px; box-shadow:0 6px 20px rgba(0,0,0,0.1); width:400px;}
h2{text-align:center; margin-bottom:20px; color:#111827;}
input,button{width:100%; padding:12px; margin:8px 0; border-radius:8px; border:1px solid #ccc;}
input:focus{border-color:#2563eb; box-shadow:0 0 5px #2563eb33;}
button{border:none; background:#2563eb; color:#fff; cursor:pointer;}
button:hover{background:#1d4ed8;}
.message{text-align:center; color:red; margin-bottom:15px;}
.register-link{text-align:center; margin-top:10px;}
.register-link a{color:#2563eb; text-decoration:none;}
.register-link a:hover{text-decoration:underline;}
</style>
</head>
<body>
<div class="container">
<h2>Login</h2>
<?php if($message) echo "<div class='message'>$message</div>"; ?>
<form method="POST">
<input type="email" name="email" placeholder="Email Address" required>
<input type="password" name="password" placeholder="Password" required>
<button name="login">Login</button>
</form>
<div class="register-link">
Don't have an account? <a href="register.php">Register</a>
</div>
</div>
</body>
</html>
