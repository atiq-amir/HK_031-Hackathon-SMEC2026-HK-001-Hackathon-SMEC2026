<?php
session_start();
include 'db.php';

if (!isset($_SESSION['user_id'])) {
    echo json_encode([]);
    exit;
}

$user_id = $_SESSION['user_id'];
$role = $_SESSION['role'];

if ($role === 'passenger') {
    $stmt = $conn->prepare("
        SELECT id, status, driver_id
        FROM ride_requests
        WHERE passenger_id = ?
    ");
    $stmt->execute([$user_id]);
}

if ($role === 'driver') {
    $stmt = $conn->prepare("
        SELECT id, status
        FROM ride_requests
        WHERE driver_id = ?
    ");
    $stmt->execute([$user_id]);
}

echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
