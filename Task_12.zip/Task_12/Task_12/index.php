<?php
session_start();
if(!isset($_SESSION['user_id'])){
    header("Location: login.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>RideShare - Dashboard</title>
<style>
/* Base Reset */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: 'Inter', 'Segoe UI', sans-serif;
}

/* Body */
body {
    background: #f5f7fa;
    color: #1f2937;
    min-height: 100vh;
}

/* Navbar */
.navbar {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 15px 40px;
    background: #2563eb;
    color: #fff;
    box-shadow: 0 4px 12px rgba(0,0,0,0.05);
}

.navbar .logo {
    font-weight: 700;
    font-size: 22px;
}

.navbar .user-info {
    display: flex;
    align-items: center;
    gap: 20px;
}

.navbar .user-info span {
    font-weight: 500;
}

/* Logout button in navbar */
.navbar .logout-btn {
    background: #ef4444;
    color: #fff;
    padding: 8px 16px;
    border-radius: 6px;
    text-decoration: none;
    font-weight: 500;
    transition: background 0.3s ease;
}

.navbar .logout-btn:hover {
    background: #b91c1c;
}

/* Main content */
.main {
    padding: 40px;
    display: flex;
    justify-content: center;
}

/* Card container */
.cards {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
    gap: 30px;
    width: 100%;
    max-width: 900px;
}

/* Individual cards */
.card {
    background: #fff;
    padding: 30px 20px;
    border-radius: 16px;
    box-shadow: 0 10px 25px rgba(0,0,0,0.08);
    text-align: center;
    transition: transform 0.3s ease, box-shadow 0.3s ease;
    cursor: pointer;
    text-decoration: none;
    color: #1f2937;
}

.card:hover {
    transform: translateY(-5px);
    box-shadow: 0 15px 35px rgba(0,0,0,0.12);
}

/* Card icon */
.card .icon {
    font-size: 40px;
    margin-bottom: 20px;
    color: #2563eb;
}

/* Card title */
.card h3 {
    font-size: 20px;
    margin-bottom: 10px;
}

/* Card description */
.card p {
    font-size: 14px;
    color: #6b7280;
}

/* Responsive adjustments */
@media(max-width: 600px) {
    .navbar {
        flex-direction: column;
        align-items: flex-start;
        gap: 10px;
    }

    .cards {
        grid-template-columns: 1fr;
        gap: 20px;
    }
}
</style>
<!-- Optional: Add icons from font-awesome CDN -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>

<!-- Navbar -->
<div class="navbar">
    <div class="logo">RideShare</div>
    <div class="user-info">
        <span><?= htmlspecialchars($_SESSION['name']) ?></span>
        <a href="logout.php" class="logout-btn">Logout</a>
    </div>
</div>

<!-- Main content -->
<div class="main">
    <div class="cards">
        <?php if($_SESSION['role'] == 'passenger'): ?>
            <a href="request_ride.php" class="card">
                <div class="icon"><i class="fas fa-taxi"></i></div>
                <h3>Request a Ride</h3>
                <p>Find the best driver for your route quickly and safely.</p>
            </a>
            <a href="history.php" class="card">
                <div class="icon"><i class="fas fa-history"></i></div>
                <h3>My Ride History</h3>
                <p>Review all your past rides and track payments.</p>
            </a>
        <?php else: ?>
            <a href="driver_requests.php" class="card">
                <div class="icon"><i class="fas fa-route"></i></div>
                <h3>Pending Ride Requests</h3>
                <p>View and accept ride requests from passengers near you.</p>
            </a>
            <a href="history.php" class="card">
                <div class="icon"><i class="fas fa-history"></i></div>
                <h3>My Ride History</h3>
                <p>Check your completed rides and earnings.</p>
            </a>
        <?php endif; ?>
    </div>
</div>

</body>
</html>
