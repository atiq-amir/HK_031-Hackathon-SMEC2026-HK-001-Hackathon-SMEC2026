<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}
?>
<!DOCTYPE html>
<html>
<head>
<title>Ride Route</title>
<style>
body {
    font-family: 'Segoe UI', sans-serif;
    background: #f4f6f8;
    padding: 20px;
}
.container {
    max-width: 900px;
    margin: auto;
    background: #fff;
    padding: 20px;
    border-radius: 12px;
}
h2 {
    text-align: center;
}
</style>
</head>
<body>

<div class="container">
<h2>Ride Route</h2>
<?php include 'map.php'; ?>
</div>

</body>
</html>
