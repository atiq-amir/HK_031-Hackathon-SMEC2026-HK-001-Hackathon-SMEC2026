folder xaamp m paste hoga


jis folder m file rkhi ha usko cmd sy open kro or ye command cmd p run kro

composer install


isky bad ye command same cmd p run kro

php signaling-server.php



apny chrome p ye  http://localhost/a/index.php


phr ek new cmd open kro command likho 


ipconfig

ipv4 address copy krlyn


dosra laptop on kryn same wifi p hona chahye


dosry laptop k chorome p (e.g. http://192.168.0.5/your-folder/index.php)  apny laptop ka ip adress /a/index.php




