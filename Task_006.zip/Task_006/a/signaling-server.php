<?php
require __DIR__ . '/vendor/autoload.php';

use Ratchet\MessageComponentInterface;
use Ratchet\ConnectionInterface;
use Ratchet\Http\HttpServer;
use Ratchet\WebSocket\WsServer;
use Ratchet\Server\IoServer;

class SignalingServer implements MessageComponentInterface {
    protected $clients;
    protected $info; // connId => ['id' => clientId, 'room' => room, 'name' => name]

    public function __construct() {
        $this->clients = new \SplObjectStorage;
        $this->info = [];
    }

    public function onOpen(ConnectionInterface $conn) {
        $this->clients->attach($conn);
        $this->info[$conn->resourceId] = ['id' => null, 'room' => null, 'name' => null];
    }

    public function onMessage(ConnectionInterface $from, $msg) {
        $data = json_decode($msg, true);
        if (!$data) return;

        $rid = $from->resourceId;

        if ($data['type'] === 'join') {
            $room = $data['room'] ?? null;
            $cid  = $data['clientId'] ?? null;
            $name = $data['name'] ?? 'User';

            $this->info[$rid]['id'] = $cid;
            $this->info[$rid]['room'] = $room;
            $this->info[$rid]['name'] = $name;

            // Pehle se room me jo clients hain unke ids naya user ko bhejo
            $peers = [];
            foreach ($this->clients as $client) {
                $i = $this->info[$client->resourceId];
                if ($client !== $from && $i['room'] === $room && $i['id']) {
                    $peers[] = $i['id'];
                }
            }
            $from->send(json_encode([
                'type'  => 'peers',
                'room'  => $room,
                'peers' => $peers
            ]));

            // Sab ko batado ki naya banda aaya (participants + info)
            foreach ($this->clients as $client) {
                $i = $this->info[$client->resourceId];
                if ($i['room'] === $room && $client !== $from) {
                    $client->send(json_encode([
                        'type'     => 'join',
                        'room'     => $room,
                        'clientId' => $cid,
                        'name'     => $name
                    ]));
                }
            }
            return;
        }

        if (in_array($data['type'], ['offer', 'answer', 'candidate'], true)) {
            $toId = $data['to'] ?? null;
            $room = $data['room'] ?? null;
            foreach ($this->clients as $client) {
                $i = $this->info[$client->resourceId];
                if ($i['id'] === $toId && $i['room'] === $room) {
                    $client->send($msg);
                    break;
                }
            }
            return;
        }

        if ($data['type'] === 'chat') {
            $room = $data['room'] ?? null;
            foreach ($this->clients as $client) {
                $i = $this->info[$client->resourceId];
                if ($i['room'] === $room) {
                    $client->send($msg);
                }
            }
            return;
        }
    }

    public function onClose(ConnectionInterface $conn) {
        $rid = $conn->resourceId;
        $info = $this->info[$rid] ?? null;

        $this->clients->detach($conn);
        unset($this->info[$rid]);

        if ($info && $info['room'] && $info['id']) {
            foreach ($this->clients as $client) {
                $i = $this->info[$client->resourceId];
                if ($i['room'] === $info['room']) {
                    $client->send(json_encode([
                        'type'     => 'leave',
                        'room'     => $info['room'],
                        'clientId' => $info['id']
                    ]));
                }
            }
        }
    }

    public function onError(ConnectionInterface $conn, \Exception $e) {
        $conn->close();
    }
}

$server = IoServer::factory(
    new HttpServer(
        new WsServer(
            new SignalingServer()
        )
    ),
    8080
);

echo "Signaling server running on ws://0.0.0.0:8080\n";
$server->run();