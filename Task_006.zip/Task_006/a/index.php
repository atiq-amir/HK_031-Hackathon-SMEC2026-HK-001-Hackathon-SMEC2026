<?php
// Simple file upload handling (File Sharing)
$uploadMessage = "";
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['shared_file'])) {
    $targetDir = __DIR__ . "/uploads/";
    if (!file_exists($targetDir)) {
        mkdir($targetDir, 0777, true);
    }

    $fileName = basename($_FILES['shared_file']['name']);
    $targetFile = $targetDir . $fileName;

    if (move_uploaded_file($_FILES['shared_file']['tmp_name'], $targetFile)) {
        $uploadMessage = "File uploaded successfully: " . htmlspecialchars($fileName);
    } else {
        $uploadMessage = "File upload failed.";
    }
}

// Get list of uploaded files
$files = [];
$uploadDirPath = __DIR__ . "/uploads/";
if (file_exists($uploadDirPath)) {
    $files = array_diff(scandir($uploadDirPath), ['.', '..']);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Simple Video Conference + Collaboration</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            background: #f5f5f5;
        }
        .header {
            background: #1f2937;
            color: white;
            padding: 10px 20px;
        }
        .header h1 {
            margin: 0;
            font-size: 20px;
        }
        .container {
            display: flex;
            height: calc(100vh - 50px);
        }
        .left-panel, .right-panel {
            padding: 10px;
            box-sizing: border-box;
        }
        .left-panel {
            width: 60%;
            border-right: 1px solid #ddd;
            display: flex;
            flex-direction: column;
            gap: 10px;
        }
        .right-panel {
            width: 40%;
            display: flex;
            flex-direction: column;
            gap: 10px;
        }
        .section {
            background: white;
            border-radius: 6px;
            padding: 10px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.08);
        }
        .section h2 {
            margin-top: 0;
            font-size: 16px;
            border-bottom: 1px solid #eee;
            padding-bottom: 5px;
        }
        video {
            width: 100%;
            max-height: 250px;
            background: black;
        }
        .controls button {
            padding: 6px 10px;
            margin-right: 5px;
            margin-top: 5px;
            cursor: pointer;
        }
        canvas {
            border: 1px solid #ccc;
            width: 100%;
            height: 250px;
            cursor: crosshair;
        }
        .file-list a {
            display: block;
            margin-bottom: 5px;
        }
        .upload-msg {
            color: green;
            margin-top: 5px;
        }
        .note {
            font-size: 12px;
            color: #555;
        }
    </style>
</head>
<body>
<div class="header">
    <h1>Simple Video Conferencing + Collaboration Tool (Demo)</h1>
</div>

<div class="container">
    <!-- LEFT: Video + Screen Sharing -->
    <div class="left-panel">
        <!-- Video Calling Section -->
        <div class="section">
            <h2>Video Calling (Demo)</h2>
            <p class="note">
                This demo shows your own camera as a "participant". Real multi-user video
                would need a signaling server + WebRTC on backend.
            </p>
            <video id="localVideo" autoplay playsinline></video>
            <div class="controls">
                <button onclick="startCamera()">Start Camera</button>
                <button onclick="stopCamera()">Stop Camera</button>
            </div>
        </div>

        <!-- Screen Sharing Section -->
        <div class="section">
            <h2>Screen Sharing</h2>
            <p class="note">
                Click start to share your screen. Browser will ask for permission.
            </p>
            <video id="screenVideo" autoplay playsinline></video>
            <div class="controls">
                <button onclick="startScreenShare()">Start Screen Share</button>
                <button onclick="stopScreenShare()">Stop Screen Share</button>
            </div>
        </div>
    </div>

    <!-- RIGHT: File Sharing + Whiteboard -->
    <div class="right-panel">
        <!-- File Sharing Section -->
        <div class="section">
            <h2>File Sharing</h2>
            <form method="post" enctype="multipart/form-data">
                <label>Select file to share:</label><br>
                <input type="file" name="shared_file" required>
                <br><br>
                <button type="submit">Upload</button>
            </form>
            <?php if (!empty($uploadMessage)): ?>
                <div class="upload-msg"><?php echo $uploadMessage; ?></div>
            <?php endif; ?>

            <h3>Shared Files</h3>
            <div class="file-list">
                <?php if (empty($files)): ?>
                    <span>No files shared yet.</span>
                <?php else: ?>
                    <?php foreach ($files as $file): ?>
                        <a href="<?php echo 'uploads/' . urlencode($file); ?>" target="_blank">
                            <?php echo htmlspecialchars($file); ?>
                        </a>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>

        <!-- Whiteboard Section -->
        <div class="section">
            <h2>Whiteboard</h2>
            <p class="note">
                Draw using your mouse. Click "Clear" to erase.
            </p>
            <canvas id="whiteboard"></canvas>
            <div class="controls">
                <button onclick="clearBoard()">Clear</button>
            </div>
        </div>
    </div>
</div>

<script>
// ====== Video Calling (local camera demo) ======
let cameraStream = null;

async function startCamera() {
    try {
        cameraStream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
        const video = document.getElementById('localVideo');
        video.srcObject = cameraStream;
    } catch (err) {
        alert('Could not access camera/mic: ' + err.message);
    }
}

function stopCamera() {
    if (cameraStream) {
        cameraStream.getTracks().forEach(track => track.stop());
        cameraStream = null;
        document.getElementById('localVideo').srcObject = null;
    }
}

// ====== Screen Sharing ======
let screenStream = null;

async function startScreenShare() {
    try {
        screenStream = await navigator.mediaDevices.getDisplayMedia({ video: true });
        const screenVideo = document.getElementById('screenVideo');
        screenVideo.srcObject = screenStream;
    } catch (err) {
        alert('Screen share failed: ' + err.message);
    }
}

function stopScreenShare() {
    if (screenStream) {
        screenStream.getTracks().forEach(track => track.stop());
        screenStream = null;
        document.getElementById('screenVideo').srcObject = null;
    }
}

// ====== Whiteboard (Canvas Drawing) ======
const canvas = document.getElementById('whiteboard');
const ctx = canvas.getContext('2d');

// Resize canvas to container size
function resizeCanvas() {
    canvas.width = canvas.clientWidth;
    canvas.height = canvas.clientHeight;
}
window.addEventListener('resize', resizeCanvas);
resizeCanvas();

let drawing = false;
let lastX = 0;
let lastY = 0;

canvas.addEventListener('mousedown', (e) => {
    drawing = true;
    [lastX, lastY] = getMousePos(e);
});

canvas.addEventListener('mousemove', (e) => {
    if (!drawing) return;
    const [x, y] = getMousePos(e);
    ctx.strokeStyle = '#000';
    ctx.lineWidth = 2;
    ctx.lineCap = 'round';

    ctx.beginPath();
    ctx.moveTo(lastX, lastY);
    ctx.lineTo(x, y);
    ctx.stroke();
    [lastX, lastY] = [x, y];
});

canvas.addEventListener('mouseup', () => drawing = false);
canvas.addEventListener('mouseleave', () => drawing = false);

function getMousePos(e) {
    const rect = canvas.getBoundingClientRect();
    return [
        e.clientX - rect.left,
        e.clientY - rect.top
    ];
}

function clearBoard() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
}
</script>
</body>
</html>